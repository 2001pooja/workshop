package Miniproject1.Miniproject1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Snapdeal {
 
			public static void main(String[] args) {
			
				//Creating an object of Scanner Class for the Input
						Scanner sc=new Scanner(System.in);
						
						WebDriver driver = null;
						//Printing the browser selection statement
						System.out.println("Choose a browser:\n1.Chrome Browser\n2.Edge Browser\n");
						
						
						//Assigning the value to Option
						int option=sc.nextInt();
						
						
						
						//Selection of the Web Browser
						switch(option) {
						case 1:
							System.out.println("\nYou Selected Chrome Browser");
							driver=new ChromeDriver();
							break;
						case 2:
							System.out.println("\nYou Selected Edge Browser");
							driver=new EdgeDriver();
							break;
						default:
							System.out.println("\nInvalid Number Entered");
							break;
						}
						
						
						//Closure of the scanner object
						sc.close();
						
						
						
						//Open snapdeal website
						driver.get("https://www.snapdeal.com/");										
						
						
						
						//Maximize the Window
						driver.manage().window().maximize();											
						
						
						
						//Setting of implicit Wait Time
						driver.manage().timeouts().implicitlyWait(java.time.Duration.ofMinutes(5));		
						
						
						
						
						//Check if the home page of the application is loaded
						try{
							driver.findElement(By.xpath("//img[@title='Snapdeal']"));
							System.out.println("\nHome page loaded successfully");
						}
						catch(NoSuchElementException e){
							System.out.println("\nHome page did not loaded successfully");
						}
						
						
						
						
						//In the search box enter the search criteria “Home appliances”.
						WebElement cart=driver.findElement(By.name("keyword"));
						cart.sendKeys("Home appliances");
						cart.sendKeys(Keys.ENTER);
				
						
					
						//Click on the first product and add to the cart.
						driver.findElement(By.xpath("//div[@class='product-desc-rating ']//a[@pogid='685000762995']")).click();
						Set<String> s= driver.getWindowHandles();
						ArrayList ar=new ArrayList(s);
						driver.switchTo().window((String)ar.get(1));
						WebElement addToCart=driver.findElement(By.id("add-cart-button-id"));
						addToCart.click();
				
						
						
						
						//Display the order amount in console.
						String cost=driver.findElement(By.className("price")).getText();
						System.out.println("\nCost of First product "+cost);
				
						
						
						
						//Close the new tab and go back to Home appliances page again.
						driver.close();
						driver.switchTo().window((String)ar.get(0));
				
						
						
						
						//Add one more item to the cart.
						driver.findElement(By.xpath("//div[@class='product-desc-rating ']//p[text()='HOMETALES Single Polyester Green Microwave Oven Cover - 20-22L']")).click();
						Set<String> ss= driver.getWindowHandles();
						ArrayList<String> arr=new ArrayList<String>(ss);
						driver.switchTo().window((String)arr.get(1));
						WebElement addToCart1=driver.findElement(By.id("add-cart-button-id"));
						addToCart1.click();
						
						
						//Display the revised Total order amount in the console.
						String cost1=driver.findElement(By.xpath("//div[@class='you-pay']//span")).getText();
						
						
						
						//Validate if the amount is properly calculated.
						String cost2=driver.findElement(By.xpath("//div[@class='col-xs-18']//span[@class='price']")).getText();
						int Actual_Price=0;
						try {
							if(cost1!=null && cost1.length()>4 && cost1.substring(0, 4).equalsIgnoreCase("Rs. ")) {
								cost1=cost1.substring(4);
							}
							System.out.println("\nTotal Cost is "+cost1);
							Actual_Price = Integer.parseInt(cost1);
						} catch (NumberFormatException e) {
							
							System.out.println("Encountered an exception while converting cost1");
							e.printStackTrace();
						}
						int Expected_Price = 0;
						try {
							if(cost!=null && cost.length()>4 && cost.substring(0, 4).equals("Rs. ")) {
								cost=cost.substring(4);
							}
							if(cost2!=null && cost2.length()>4 && cost2.substring(0, 4).equals("Rs. ")) {
								cost2=cost2.substring(4);
							}
							System.out.println("\nCost of Fisrt product "+cost+" and Cost of Second Product is "+cost2);
							Expected_Price = Integer.parseInt(cost) + Integer.parseInt(cost2);
						} catch (NumberFormatException e) {
							
							System.out.println("Encountered an exception while converting cost and cost2");
							e.printStackTrace();
						}
						
						try {
						if(Actual_Price==Expected_Price){
							System.out.println("\n199+199=398 \n\nTotal Price validation successfully!");
						}else {
							System.out.println("\nTotal Price Validation failed!");
						}
						}
						catch(NumberFormatException e) {
							System.out.println("\nInvalid");
						}
						
						
						
						//Close the browser
						driver.quit();
					}
		 
			}
		
